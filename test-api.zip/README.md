# Azure Key Vault Integration with Spring Boot

A Spring Boot application that demonstrates secure integration with Azure Key Vault using service principal authentication.

## Features

- **Service Principal Authentication**: Secure authentication using Azure AD service principal
- **Secret Retrieval**: Retrieve secrets from Azure Key Vault with proper error handling
- **Spring Boot Integration**: Native Spring Boot configuration and dependency injection
- **REST API**: Simple REST endpoints to demonstrate Key Vault operations
- **Comprehensive Logging**: Detailed logging for troubleshooting and monitoring
- **Error Handling**: Robust exception handling with meaningful error messages

## Prerequisites

- Java 17 or higher
- Maven 3.6 or higher
- Azure subscription with Key Vault access
- Azure AD service principal with Key Vault permissions

## Azure Setup

### 1. Create Azure Key Vault

```bash
# Create resource group
az group create --name myResourceGroup --location eastus

# Create Key Vault
az keyvault create --name myKeyVault --resource-group myResourceGroup --location eastus
```

### 2. Create Service Principal

```bash
# Create service principal
az ad sp create-for-rbac --name myKeyVaultApp --skip-assignment

# Note the output:
# {
#   "appId": "your-client-id",
#   "displayName": "myKeyVaultApp",
#   "password": "your-client-secret",
#   "tenant": "your-tenant-id"
# }
```

### 3. Grant Key Vault Permissions

```bash
# Grant secret permissions to service principal
az keyvault set-policy --name myKeyVault --spn your-client-id --secret-permissions get list
```

### 4. Add Test Secret

```bash
# Add a test secret
az keyvault secret set --vault-name myKeyVault --name "test-secret" --value "Hello from Azure Key Vault!"
```

## Configuration

Set the following environment variables:

```bash
export AZURE_CLIENT_ID=your-service-principal-client-id
export AZURE_CLIENT_SECRET=your-service-principal-client-secret
export AZURE_TENANT_ID=your-azure-tenant-id
export AZURE_KEYVAULT_URL=https://your-keyvault-name.vault.azure.net/
```

Or create an `.env` file:

```properties
AZURE_CLIENT_ID=your-service-principal-client-id
AZURE_CLIENT_SECRET=your-service-principal-client-secret
AZURE_TENANT_ID=your-azure-tenant-id
AZURE_KEYVAULT_URL=https://your-keyvault-name.vault.azure.net/
```

## Running the Application

The application automatically loads environment variables from the `.env` file using the dotenv-java library.

### Method 1: Direct Maven Run (Recommended)

```bash
mvn spring-boot:run
```

The application will automatically load variables from `.env` file.

### Method 2: Using Batch Script (Windows CMD)

```cmd
load-env.bat
```

### Method 3: Using PowerShell Script (Windows PowerShell)

```powershell
.\load-env.ps1
```

### Method 4: Manual Environment Variables

Set environment variables manually before running:

```cmd
set AZURE_CLIENT_ID=your-client-id
set AZURE_CLIENT_SECRET=your-client-secret
set AZURE_TENANT_ID=your-tenant-id
set AZURE_KEYVAULT_URL=https://your-keyvault.vault.azure.net/
mvn spring-boot:run
```

### Development Mode

```bash
# Run with development profile
mvn spring-boot:run -Dspring-boot.run.profiles=dev
```

### Production Mode

```bash
# Build the application
mvn clean package

# Run the JAR
java -jar target/azure-keyvault-integration-0.0.1-SNAPSHOT.jar
```

## API Usage

### Swagger/OpenAPI Documentation

Once the application is running, you can access the interactive API documentation:

**Swagger UI (Interactive):**
```
http://localhost:8080/swagger-ui.html
```

**OpenAPI JSON:**
```
http://localhost:8080/api-docs
```

The Swagger UI provides:
- Interactive API testing
- Complete request/response schemas
- Example values for all endpoints
- Authentication requirements
- Error response documentation

### Health Check

```bash
curl http://localhost:8080/api/keyvault/health
```

### Retrieve Secret

```bash
curl http://localhost:8080/api/keyvault/secret/test-secret
```

**Success Response:**
```json
{
  "name": "test-secret",
  "value": "Hello from Azure Key Vault!",
  "retrievedAt": "2024-01-15T10:30:00",
  "success": true,
  "errorMessage": null
}
```

**Error Response:**
```json
{
  "name": "non-existent-secret",
  "value": null,
  "retrievedAt": "2024-01-15T10:30:00",
  "success": false,
  "errorMessage": "Secret not found"
}
```

## Project Structure

```
src/
├── main/
│   ├── java/com/example/keyvault/
│   │   ├── AzureKeyVaultApplication.java      # Main application class
│   │   ├── client/
│   │   │   └── AzureKeyVaultClient.java       # Azure Key Vault client
│   │   ├── config/
│   │   │   ├── AzureKeyVaultConfiguration.java # Spring configuration
│   │   │   └── AzureKeyVaultProperties.java    # Configuration properties
│   │   ├── controller/
│   │   │   ├── GlobalExceptionHandler.java     # Global error handling
│   │   │   └── KeyVaultDemoController.java     # REST endpoints
│   │   ├── exception/
│   │   │   ├── AuthenticationFailedException.java
│   │   │   ├── KeyVaultException.java
│   │   │   ├── SecretNotFoundException.java
│   │   │   └── SecretRetrievalException.java
│   │   ├── model/
│   │   │   └── SecretResponse.java             # API response model
│   │   └── service/
│   │       └── KeyVaultService.java            # Business logic layer
│   └── resources/
│       ├── application.yml                     # Main configuration
│       └── application-dev.yml                 # Development configuration
```

## Troubleshooting

### Common Issues

1. **Authentication Failed**
   - Verify service principal credentials
   - Check if service principal has Key Vault permissions
   - Ensure tenant ID is correct

2. **Secret Not Found**
   - Verify secret exists in Key Vault
   - Check secret name spelling
   - Ensure service principal has 'get' permission

3. **Connection Issues**
   - Verify Key Vault URL format
   - Check network connectivity
   - Review firewall settings

### Logging

Enable debug logging for troubleshooting:

```yaml
logging:
  level:
    com.azure: DEBUG
    com.example.keyvault: DEBUG
```

## Security Best Practices

- Store service principal credentials as environment variables
- Use Azure Managed Identity in production environments
- Implement proper secret rotation policies
- Monitor Key Vault access logs
- Use least privilege principle for permissions

## License

This project is licensed under the MIT License.